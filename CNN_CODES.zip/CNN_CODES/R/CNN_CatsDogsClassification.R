library(keras3)
library(EBImage)

train.files<- Sys.glob(file.path("C:/Users/000110888/OneDrive - CSULB/Desktop/PetsImages/train/*.jpg"))
train.labels<- substring(basename(train.files), 1,3) #extracting label: 'cat' or 'dog'
train.lab<- as.numeric(ifelse(train.labels=='cat',1,0))

setwd("C:/Users/000110888/OneDrive - CSULB/Desktop/PetsImages/train") 
img.pets<- sample(dir()); 
train.pets<- list(NULL);        
for(i in 1:length(img.pets)) {
  train.pets[[i]]<- readImage(img.pets[i])
  train.pets[[i]]<- resize(train.pets[[i]], 100, 100)
}

train<- aperm(combine(train.pets), c(4,1,2,3)) #permuting dimensions 
 
#building model
cnn.model<- keras_model_sequential() %>%
  layer_conv_2d(filters=32, kernel_size=c(3, 3), activation="relu", 
  input_shape=c(100, 100, 3)) %>% layer_max_pooling_2d(pool_size=c(2, 2)) %>%
  layer_conv_2d(filters=64, kernel_size=c(3, 3), activation="relu") %>% 
  layer_max_pooling_2d(pool_size=c(2, 2)) %>% layer_conv_2d(filters=128, kernel_size=c(3, 3), 
  activation="relu") %>% layer_max_pooling_2d(pool_size=c(2, 2)) %>%
  layer_conv_2d(filters=128, kernel_size=c(3, 3), activation="relu") %>% 
  layer_max_pooling_2d(pool_size=c(2, 2)) %>% layer_flatten() %>% layer_dense(units=512,
  activation="relu") %>% layer_dense(units=1, activation="sigmoid")

cnn.model %>% compile(loss="binary_crossentropy", optimizer=optimizer_adam(), metrics="accuracy")

history<- cnn.model %>% fit(train, train.lab, epochs=50, batch_size=40, validation_split=0.2)

#computing prediction accuracy for testing set
setwd("C:/Users/000110888/OneDrive - CSULB/Desktop/PetsImages/ourpets") 
img.pets<- sample(dir()); 
test.pets<- list(NULL); 
for(i in 1:length(img.pets)) {
  test.pets[[i]]<- readImage(img.pets[i])
  test.pets[[i]]<- resize(test.pets[[i]], 100, 100)
}

test<- aperm(combine(test.pets), c(4,1,2,3))
test.lab<- c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1)

cnn.model %>% evaluate(test, test.lab) 
pred.prob<- cnn.model %>% predict(test)

true.class<- ifelse(test.lab==1,'cat','dog')
pred.class<- c()
match<- c()
for (i in 1:length(pred.prob)){
  pred.class[i]<- ifelse(pred.prob[i]>0.5,'cat','dog')
  match[i]<- ifelse(true.class[i]==pred.class[i],1,0)
}

print(true.class)
print(pred.class)

print(paste("accuracy=", round(mean(match), digits=4)))

