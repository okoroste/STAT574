library(keras3)

mnist<- dataset_mnist()
train.x<- mnist$train$x  #x=images
train.y<- mnist$train$y  #y=labels
test.x<- mnist$test$x
test.y<- mnist$test$y

str(train.x)
str(train.y)
str(test.x)
str(test.y)

#plotting a sample image from the training set
index.image<- sample(1:60000,1) #picked randomly
input.matrix<- train.x[index.image,1:28,1:28]
output.matrix<- apply(input.matrix, 2, rev)
output.matrix<- t(output.matrix)
image(1:28, 1:28, output.matrix, col=gray.colors(256), 
xlab=paste('Image for digit of: ', train.y[index.image]), ylab="")

#plotting a sample image from the testing set
index.image<- sample(1:1000,1) #picked randomly
input.matrix<- test.x[index.image,1:28,1:28]
output.matrix<- apply(input.matrix, 2, rev)
output.matrix<- t(output.matrix)
image(1:28, 1:28, output.matrix, col=gray.colors(256), 
xlab=paste('Image for digit of: ', test.y[index.image]), ylab="")


#specifying parameters
batch.size<- 128
num.classes<- 10
epochs<- 5
img.rows<- 28
img.cols<- 28

train.x<- array_reshape(train.x, c(nrow(train.x), img.rows, img.cols, 1))
test.x<- array_reshape(test.x, c(nrow(test.x), img.rows, img.cols, 1))
input.shape<- c(img.rows, img.cols, 1)

#rescaling images
train.x<- train.x/255
test.x<- test.x/255

#converting class vectors to binary class matrices
train.y<- to_categorical(train.y, num.classes)
test.lab<- to_categorical(test.y, num.classes)

#defining model architecture 
cnn_model<- keras_model_sequential() %>%
  layer_conv_2d(filters=32, kernel_size=c(3,3), activation='relu', input_shape=input.shape) %>% 
  layer_max_pooling_2d(pool_size=c(2, 2)) %>% 
  layer_conv_2d(filters=64, kernel_size=c(3,3), activation='relu') %>% 
  layer_max_pooling_2d(pool_size=c(2, 2)) %>% 
  layer_dropout(rate=0.25) %>% 
  layer_flatten() %>% 
  layer_dense(units=128, activation='relu') %>% 
  layer_dropout(rate=0.5) %>% 
  layer_dense(units=num.classes, activation='softmax')

#compiling model
cnn_model %>% compile(loss=loss_categorical_crossentropy,
optimizer=optimizer_adam(), metrics=c('accuracy'))

#training model
cnn_model %>% fit(train.x, train.y, batch_size=batch.size,
epochs=epochs, validation_split=0.2)

#computing prediction accuracy
cnn_model %>% evaluate(test.x, test.lab)

pred.prob<- predict(cnn_model, test.x)

pred.class<- c()
for (i in 1:nrow(pred.prob))
pred.class[i]<- which.max(pred.prob[i,])-1

head(pred.class, n=50)
head(test.y, n=50)

print(paste("accuracy=", round(1-mean(test.y!=pred.class), digits=4)))

#displaying misclassified images
missed.image<- mnist$test$x[pred.class != mnist$test$y,,]
missed.digit<- mnist$test$y[pred.class != mnist$test$y]
missed.pred<- pred.class[pred.class != mnist$test$y]

index.image<- sample(1:length(missed.pred),1)
input.matrix<- missed.image[index.image,1:28,1:28]
output.matrix<- apply(input.matrix, 2, rev)
output.matrix <- t(output.matrix)
image(1:28, 1:28, output.matrix, col=gray.colors(256), 
xlab=paste('Image for digit ', missed.digit[index.image], 
', wrongly predicted as ', missed.pred[index.image]), ylab="")