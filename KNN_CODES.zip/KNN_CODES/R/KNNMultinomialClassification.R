movie.data<- read.csv(file="C:/Users/000110888/OneDrive - CSULB/Desktop/movie_data.csv", 
header=TRUE, sep=",")
            
#SPLITTING DATA INTO 80% TRAINING AND 20% TESTING SETS 
library(caTools)
set.seed(499251)
sample<- sample.split(movie.data, SplitRatio=0.8)
train<- subset(movie.data, sample==TRUE)
test<-  subset(movie.data, sample==FALSE)

train.x<- data.matrix(train[-5])
train.y<- data.matrix(train[5])
test.x<- data.matrix(test[-5])
test.y<- data.matrix(test[5])

#FITTING K-NEAREST NEIGHBOR MULTINOMIAL CLASSIFIER 
#k=9 reasonably maximizes prediction accuracy for testing set
library(caret)
knn.mclass<- knnreg(train.x, train.y, k=9)

#COMPUTING PREDICTION ACCURACY FOR TESTING DATA 
pred.y<- round(predict(knn.mclass, test.x), digits=0)
print(paste("accuracy=", round(1-mean(test.y!=pred.y),digits=4)))

