#install.packages(c("gutenbergr", "stringr", "dplyr", "tidytext", "tibble", 
#"ggraph", "wordcloud")) 

library(gutenbergr)
library(stringr)
library(dplyr)
library(tidytext)
library(tibble)
library(ggplot2)
library(wordcloud)

print(gutenberg_works(author == "Shakespeare, William"), n=100)

book<- gutenberg_download(1513, mirror="http://mirror.csclub.uwaterloo.ca/gutenberg/", meta_fields="author")
#24022,37431, 1, 2489, 108, 1513, 11
#puts text into tibble format
book<- as_tibble(book) %>% 
  mutate(document = row_number()) %>% 
  select(-gutenberg_id)

#creating tokens (words)
tidy_book <- book %>%
  unnest_tokens(word, text) %>%
  group_by(word) %>%
  filter(n() > 10) %>%
  ungroup()

#identifying and removing stopwords (prepositions, articles)
stopword <- as_tibble(stopwords::stopwords("en")) 
stopword <- rename(stopword, word=value)
tb <- anti_join(tidy_book, stopword, by='word')

#plotting word cloud
tb %>%
  count(word) %>%
  with(wordcloud(word, n, max.words=50, colors=brewer.pal(8, "Dark2")))

