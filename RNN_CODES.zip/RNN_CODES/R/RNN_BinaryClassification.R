tsla.data<- read.csv(file="C:/Users/000110888/OneDrive - CSULB/Desktop/TSLA_Shocks.csv", 
header=TRUE, sep=",")

#splitting data into testing and training sets
tsla.data$Year<- as.numeric(format(as.Date(tsla.data$Date, format="%Y-%m-%d"),"%Y"))
train.data<- tsla.data[which(tsla.data$Year<2022),1:2]
test.data<- tsla.data[which(tsla.data$Year>=2022),1:2]

nsteps<- 60 #width of sliding window
train.matrix <- matrix(nrow=nrow(train.data)-nsteps, ncol=nsteps+1)
for (i in 1:(nrow(train.data)-nsteps))
  train.matrix[i,]<- tsla.data$Shock[i:(i+nsteps)]

train.x<- array(train.matrix[,-ncol(train.matrix)],dim=c(nrow(train.matrix),nsteps,1))
train.y<- train.matrix[,ncol(train.matrix)]

#creating test.x and test.y
test.matrix<- matrix(nrow=nrow(test.data), ncol=nsteps+1)
for (i in 1:nrow(test.data)) 
  test.matrix[i,]<- tsla.data$Shock[(i+nrow(train.matrix)):(i+nsteps+nrow(train.matrix))]

test.x<- array(test.matrix[,-ncol(test.matrix)],dim=c(nrow(test.matrix),nsteps,1))
test.y<- test.matrix[,ncol(test.matrix)]

##############################################################
#FITTING LSTM MODEL
##############################################################
library(keras) 
#defining model architecture
LSTM.biclass<- keras_model_sequential()
LSTM.biclass %>% layer_dense(input_shape=dim(train.x)[2:3], units=nsteps)
LSTM.biclass %>% layer_lstm(units=25)
LSTM.biclass %>% layer_dense(units=1, activation="sigmoid") 
LSTM.biclass %>% compile(loss="binary_crossentropy")

#training model
LSTM.biclass %>% fit(train.x, train.y, batch_size=32, epochs=5)

#computing prediction accuracy for testing data
pred.prob<- LSTM.biclass %>% predict(test.x) 
match<- cbind(test.y, pred.prob)
tp<- matrix(NA, nrow=nrow(match), ncol=99)
tn<- matrix(NA, nrow=nrow(match), ncol=99)

for (i in 1:99) {
  tp[,i]<- ifelse(match[,1]==1 & match[,2]>0.01*i,1,0)
  tn[,i]<- ifelse(match[,1]==0 & match[,2]<=0.01*i,1,0)
}

trueclassrate<- matrix(NA, nrow=99, ncol=2)
for (i in 1:99){
  trueclassrate[i,1]<- 0.01*i
  trueclassrate[i,2]<- sum(tp[,i]+tn[,i])/nrow(match)
}

print(trueclassrate[which(trueclassrate[,2]==max(trueclassrate[,2])),])

##############################################################
#FITTING GRU MODEL
##############################################################
#defining model architecture
GRU.biclass<- keras_model_sequential()
GRU.biclass %>% layer_dense(input_shape=dim(train.x)[2:3], units=nsteps)
GRU.biclass %>% layer_gru(units=25)
GRU.biclass %>% layer_dense(units=1, activation="sigmoid") 
GRU.biclass %>% compile(loss="binary_crossentropy")

#training model
GRU.biclass %>% fit(train.x, train.y, batch_size=32, epochs=5)

#computing prediction accuracy for testing data
pred.prob<- GRU.biclass %>% predict(test.x) 
match<- cbind(test.y, pred.prob)
tp<- matrix(NA, nrow=nrow(match), ncol=99)
tn<- matrix(NA, nrow=nrow(match), ncol=99)

for (i in 1:99) {
  tp[,i]<- ifelse(match[,1]==1 & match[,2]>0.01*i,1,0)
  tn[,i]<- ifelse(match[,1]==0 & match[,2]<=0.01*i,1,0)
}

trueclassrate<- matrix(NA, nrow=99, ncol=2)
for (i in 1:99){
  trueclassrate[i,1]<- 0.01*i
  trueclassrate[i,2]<- sum(tp[,i]+tn[,i])/nrow(match)
}

print(trueclassrate[which(trueclassrate[,2]==max(trueclassrate[,2])),])
