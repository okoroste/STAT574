# downloading data from https://finance.yahoo.com/

library(yahoofinancer)

TSLA<- Ticker$new('TSLA')
TSLA.stock<- TSLA$get_history(start = '2020-01-02', 
end = '2025-03-18', interval = '1d')

TSLA.stock$date<- substr(as.POSIXct(strftime(TSLA.stock$date, 
format="%Y-%m-%d %H:%M:%S"), format = "%Y-%m-%d", tz=""), 1, 10)

TSLA.data<- as.data.frame(list(TSLA.stock$date, round(TSLA.stock$close,2)),
col.names=c("Date", "Close"), make.names=FALSE)

TSLA.data<- na.omit(TSLA.data)

write.csv(TSLA.data, "C:/Users/000110888/OneDrive - CSULB/Desktop/TSLA_Data_scraped.csv",
row.names=TRUE)


