#################################
#Illustration of KNN Regression #
#################################

sampledots.reg<- read.csv(file="C:/Users/000110888/OneDrive - CSULB/Desktop/SamplePoints_KNN_reg.csv",
sep=",", header=TRUE)

plot(sampledots.reg$x, sampledots.reg$y, xlim=c(0,6), ylim=c(0,6), xlab="x",
ylab="y", main="Illustration of k-Nearest Neighbor Regression", pch=16)

#sample point for prediction
for (grid in seq(0, 6, 0.1)) {
distance<- c()

for (z in 1:length(sampledots.reg$x))  
 distance[z]<- abs(grid-sampledots.reg$x[z])

min.dist3<- sort(distance)[1:3] # 3 nearest neighbors
y.pred3<- mean(sampledots.reg$y[which(distance %in% min.dist3)])
points(grid,y.pred3,col="red", pch=16)

min.dist5<- sort(distance)[1:5] # 5 nearest neighbors
y.pred5<- mean(sampledots.reg$y[which(distance %in% min.dist5)])
points(grid,y.pred5,col="blue", pch=16)

min.dist7<- sort(distance)[1:7] # 7 nearest neighbors
y.pred7<- mean(sampledots.reg$y[which(distance %in% min.dist7)])
points(grid,y.pred7,col="purple", pch=16)

}
legend("bottomright",c("k=3","k=5","k=7"),lty=1,lwd=3,col=c("red","blue","purple"),
cex = 0.7, text.col=c("red","blue","purple"))


############################################
#Illustration of KNN Binary Classification #
############################################

sampledots.bc<- read.csv(file="C:/Users/000110888/OneDrive - CSULB/Desktop/SamplePoints_KNN_biclass.csv",
sep=",", header=TRUE)

plot(sampledots.bc$x, sampledots.bc$y, xlim=c(0,6), ylim=c(0,6), xlab="x",
ylab="y", main="Illustration of k-Nearest Neighbor Binary Classification",
col=sampledots.bc$color, pch=16)

k<- 5 # five nearest neighbors 
for (i in seq(0, 6, 0.1)) {
  for (j in seq(0, 6, 0.1)) {

  distance.sq<- c()
    for (z in 1:length(sampledots.bc$x))  
      distance.sq[z]<- (i-sampledots.bc$x[z])^2+(j-sampledots.bc$y[z])^2

min.values<- sort(distance.sq)[1:k]
min.colors<- sampledots.bc$color[which(distance.sq %in% min.values)]
pred.color<- names(sort(table(min.colors), decreasing=TRUE)[1])

if (pred.color=="red") col.dot="pink" else col.dot="skyblue"
points(i,j,col=col.dot, pch=16)
  }
}

points(sampledots.bc$x, sampledots.bc$y, xlim=c(0,6), ylim=c(0,6), 
col=sampledots.bc$color, pch=16)

#################################################
#Illustration of KNN Multinomial Classification #
#################################################

sampledots.bc<- read.csv(file="C:/Users/000110888/OneDrive - CSULB/Desktop/SamplePoints_KNN_multiclass.csv",
sep=",", header=TRUE)

plot(sampledots.bc$x, sampledots.bc$y, xlim=c(0,6), ylim=c(0,6), xlab="x",
ylab="y", main="Illustration of k-Nearest Neighbor Multinomial Classification",
col=sampledots.bc$color, pch=16)

k<- 5 # five nearest neighbors 
for (i in seq(0, 6, 0.1)) {
  for (j in seq(0, 6, 0.1)) {
    
    distance.sq<- c()
    for (z in 1:length(sampledots.bc$x))  
      distance.sq[z]<- (i-sampledots.bc$x[z])^2+(j-sampledots.bc$y[z])^2
    
    min.values<- sort(distance.sq)[1:k]
    min.colors<- sampledots.bc$color[which(distance.sq %in% min.values)]
    pred.color<- names(sort(table(min.colors), decreasing=TRUE)[1])
  
    if (pred.color=="red") col.dot="pink"
    if (pred.color=="blue") col.dot="skyblue"
    if (pred.color=="green") col.dot="darkolivegreen1"
    points(i,j,col=col.dot, pch=16)
  }
}

points(sampledots.bc$x, sampledots.bc$y, xlim=c(0,6), ylim=c(0,6), 
col=sampledots.bc$color, pch=16)


